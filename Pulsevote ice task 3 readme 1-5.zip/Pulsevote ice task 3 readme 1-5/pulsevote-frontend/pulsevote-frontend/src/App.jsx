import { useState, useEffect } from 'react'
import './App.css'

function App() {

return (
    <>
        <h2>Welcome to PulseVote</h2>
    </>
)
}

export default App
