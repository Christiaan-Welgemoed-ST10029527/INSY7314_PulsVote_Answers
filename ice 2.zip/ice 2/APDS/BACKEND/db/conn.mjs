import { MongoClient } from "mongodb";
import dotenv from "dotenv";
dotenv.config();

const connectionString = process.env.ATLAS_URI || "";

const client = new MongoClient(connectionString);
let conn;

try {
  conn = await client.connect();
  console.log('mongoDB is CONNECTED!! :)');
} catch (e) {
  console.error(e);
}

// Change the database name from "users" to "test"
let db = client.db("test");

export default db;