import express from "express";
import db from "../db/conn.mjs";
import { ObjectId } from "mongodb";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import ExpressBrute from "express-brute";

const router = express.Router();

var store = new ExpressBrute.MemoryStore();
var bruteforce = new ExpressBrute(store);

// JWT secret - should be in environment variables
const JWT_SECRET = process.env.JWT_SECRET || "this_secret_should_be_longer_than_it_is";

// Get all users
router.get("/", async (req, res) => {
  try {
    const users = await db.collection("users").find({}).toArray();
    res.status(200).json(users);
  } catch (e) {
    console.error('Get users error:', e);
    res.status(500).json({ error: e.message });
  }
});

// Register a new user (with proper password hashing)
router.post("/register", async (req, res) => {
  try {
    const { name, email, password } = req.body;

    // Check if user already exists
    const existingUser = await db.collection("users").findOne({ 
      $or: [{ email }, { name }] 
    });
    
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" });
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 12);

    const newUser = {
      name,
      email,
      password: hashedPassword,
      createdAt: new Date()
    };

    const result = await db.collection("users").insertOne(newUser);
    
    // Don't return the password
    const { password: _, ...userResponse } = newUser;
    res.status(201).json({ 
      message: "User created successfully", 
      userId: result.insertedId,
      user: userResponse
    });
  } catch (e) {
    console.error('Register error:', e);
    res.status(500).json({ error: e.message });
  }
});

// Sign up (fixed version)
router.post("/signup", bruteforce.prevent, async (req, res) => {
  try {
    const { name, password, email } = req.body;

    if (!name || !password) {
      return res.status(400).json({ error: "Name and password are required" });
    }

    // Check if user already exists
    const existingUser = await db.collection("users").findOne({ name });
    if (existingUser) {
      return res.status(400).json({ error: "User already exists" });
    }

    // Hash password properly
    const hashedPassword = await bcrypt.hash(password, 12);
    
    let newDocument = {
      name,
      password: hashedPassword,
      email: email || null,
      createdAt: new Date()
    };

    let collection = await db.collection("users");
    let result = await collection.insertOne(newDocument);
    
    console.log('User created:', result.insertedId);
    
    // Return success response
    res.status(201).json({ 
      message: "User created successfully", 
      userId: result.insertedId 
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(500).json({ error: "Failed to create user" });
  }
});

// Login (improved version)
router.post("/login", bruteforce.prevent, async (req, res) => {
  try {
    const { name, password } = req.body;
    
    if (!name || !password) {
      return res.status(400).json({ message: "Name and password are required" });
    }

    console.log("Login attempt for user:", name);

    const collection = await db.collection("users");
    const user = await collection.findOne({ name });

    if (!user) {
      return res.status(401).json({ message: "Authentication failed" });
    }

    // Compare the provided password with the hashed password
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).json({ message: "Authentication failed" });
    }

    // Create JWT token
    const token = jwt.sign(
      { 
        userId: user._id,
        name: user.name
      },
      JWT_SECRET,
      { expiresIn: "24h" }
    );

    res.status(200).json({ 
      message: "Authentication successful", 
      token: token, 
      user: {
        id: user._id,
        name: user.name,
        email: user.email
      }
    });
    
    console.log("Login successful for user:", name);
  } catch (error) {
    console.error("Login error:", error);
    res.status(500).json({ message: "Login failed" });
  }
});

// Get user by ID
router.get("/:id", async (req, res) => {
  try {
    const user = await db
      .collection("users")
      .findOne({ _id: new ObjectId(req.params.id) });

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // Don't return password
    const { password, ...userResponse } = user;
    res.status(200).json(userResponse);
  } catch (e) {
    console.error('Get user by ID error:', e);
    res.status(500).json({ error: e.message });
  }
});

export default router;