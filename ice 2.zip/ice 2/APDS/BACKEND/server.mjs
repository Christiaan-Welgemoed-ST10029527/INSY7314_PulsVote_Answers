// BACKEND > js server.mjs
import https from "https";
import http from "http";
import fs from "fs";
import posts from "./routes/post.mjs";
import users from "./routes/user.mjs";
import express from "express";
import cors from "cors";

const PORT = 3001;
const app = express();

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: false }));

app.use("/post", posts);
app.use("/user", users);

// Use http.createServer instead of https.createServer to fix the EPROTO error
let server = http.createServer(app);
console.log(PORT);
server.listen(PORT);