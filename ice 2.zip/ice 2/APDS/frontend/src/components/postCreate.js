// frontend > src > components > postCreate.js
import React, { useState } from "react";
import { useNavigate } from "react-router";

export default function CreatePost() {
  const [form, setForm] = useState({
    user: "",
    content: "",
    image: "",
  });
  const navigate = useNavigate();

  // Get username from localStorage when the component mounts
  // Make sure the user is saved in localStorage as a string
  const user = localStorage.getItem("name");
  if (!user) {
    // Redirect to login if user is missing
    console.log("no user");
    navigate("/login");
  } else {
    // If user is present, update the form state
    if (form.user === "") {
      setForm((prevForm) => ({ ...prevForm, user }));
    }
  }

  // function to handle form value updates
  function updateForm(value) {
    return setForm((prev) => {
      return { ...prev, ...value };
    });
  }

  // function to handle image file change
  async function handleImageChange(e) {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        // We'll store the base64 string in the state
        updateForm({ image: reader.result });
      };
      reader.readAsDataURL(file);
    }
  }

  // function to handle form submission
  async function onSubmit(e) {
    e.preventDefault();

    const token = localStorage.getItem("jwt");
    const newPost = { ...form };

    try {
      const response = await fetch("http://localhost:3001/post/upload", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`
        },
        body: JSON.stringify(newPost),
      });

      if (!response.ok) {
        throw new Error("Network response was not ok");
      }

      await response.json();
      console.log("Post created");

      // Reset form fields after successful submission, but keep user
      setForm({ user: form.user, content: "", image: "" });
      navigate("/");
    } catch (error) {
      console.error("Error creating post:", error);
      window.alert("An error occurred while creating the post.");
    }
  }

  // This following section will display the form that takes the input from the user.
  return (
    <div className="container">
      <h3>Create New Post</h3>
      <form onSubmit={onSubmit}>
        <div className="form-group">
          <label htmlFor="user">User</label>
          <input
            type="text"
            className="form-control"
            id="user"
            value={form.user}
            disabled // Make the user field read-only
          />
        </div>
        <div className="form-group">
          <label htmlFor="content">Content</label>
          <input
            type="text"
            className="form-control"
            id="content"
            value={form.content}
            onChange={(e) => updateForm({ content: e.target.value })}
          />
        </div>
        <div className="form-group">
          <label htmlFor="image">Image</label>
          <input
            type="file"
            className="form-control"
            id="image"
            accept="image/*"
            onChange={handleImageChange}
          />
        </div>
        <div className="form-group">
          <input
            type="submit"
            value="Create Post"
            className="btn btn-primary"
          />
        </div>
      </form>
    </div>
  );
}