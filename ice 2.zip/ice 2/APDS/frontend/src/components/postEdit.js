import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";

export default function EditPost() {
  const [form, setForm] = useState({
    user: "",
    content: "",
    image: "",
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState("");
  const params = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    async function fetchData() {
      const token = localStorage.getItem("jwt");
      
      if (!token) {
        navigate("/login");
        return;
      }

      try {
        const response = await fetch(`http://localhost:3001/post/${params.id}`);
        
        if (!response.ok) {
          throw new Error("Failed to fetch post");
        }

        const post = await response.json();
        
        if (post) {
          setForm({
            user: post.user || "",
            content: post.content || "",
            image: post.image || "",
          });
        }
      } catch (error) {
        console.error("Fetch error:", error);
        setError("Failed to load post data");
      } finally {
        setIsLoading(false);
      }
    }

    fetchData();
  }, [params.id, navigate]);

  function updateForm(value) {
    return setForm((prev) => {
      return { ...prev, ...value };
    });
  }

  function handleImageChange(e) {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        updateForm({ image: reader.result });
      };
      reader.readAsDataURL(file);
    }
  }

  async function onSubmit(e) {
    e.preventDefault();
    setIsSubmitting(true);
    setError("");

    const token = localStorage.getItem("jwt");
    
    if (!token) {
      setError("You must be logged in to edit posts");
      setIsSubmitting(false);
      navigate("/login");
      return;
    }

    try {

      const updateData = {
        name: form.user,
        comment: form.content,
 
      };

      const response = await fetch(`http://localhost:3001/post/${params.id}`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify(updateData),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update post");
      }

      console.log("Post updated successfully!");
      
      navigate("/");
      
    } catch (error) {
      console.error("Update post error:", error);
      setError(error.message || "Failed to update post. Please try again.");
      
      if (error.message.includes("token")) {
        navigate("/login");
      }
    } finally {
      setIsSubmitting(false);
    }
  }

  if (isLoading) {
    return (
      <div className="container mt-5">
        <div className="text-center">
          <div className="spinner-border" role="status">
            <span className="visually-hidden">Loading...</span>
          </div>
          <p>Loading post data...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-8">
          <div className="card">
            <div className="card-header">
              <h3 className="text-center">Edit Post</h3>
            </div>
            <div className="card-body">
              {error && (
                <div className="alert alert-danger" role="alert">
                  {error}
                </div>
              )}
              
              <form onSubmit={onSubmit}>
                <div className="form-group mb-3">
                  <label htmlFor="user">User:</label>
                  <input
                    type="text"
                    className="form-control"
                    id="user"
                    value={form.user}
                    onChange={(e) => updateForm({ user: e.target.value })}
                    required
                  />
                </div>

                <div className="form-group mb-3">
                  <label htmlFor="content">Content:</label>
                  <textarea
                    className="form-control"
                    id="content"
                    rows="4"
                    value={form.content}
                    onChange={(e) => updateForm({ content: e.target.value })}
                    placeholder="What's on your mind?"
                    required
                  />
                </div>

                <div className="form-group mb-3">
                  <label htmlFor="imageFile">Upload New Image:</label>
                  <input
                    type="file"
                    className="form-control"
                    id="imageFile"
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                  <small className="form-text text-muted">
                    Optional: Select a new image to replace the current one.
                  </small>
                </div>

                <div className="form-group mb-3">
                  <label htmlFor="image">Or Image URL:</label>
                  <input
                    type="url"
                    className="form-control"
                    id="image"
                    value={form.image}
                    onChange={(e) => updateForm({ image: e.target.value })}
                    placeholder="https://example.com/image.jpg"
                  />
                </div>

                {form.image && (
                  <div className="form-group mb-3">
                    <label>Current Image:</label>
                    <div>
                      <img 
                        src={form.image} 
                        alt="Current" 
                        style={{ maxWidth: "300px", maxHeight: "300px", objectFit: "contain" }}
                        className="img-thumbnail"
                      />
                    </div>
                  </div>
                )}

                <div className="form-group text-center">
                  <button
                    type="submit"
                    className="btn btn-primary me-2"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Updating..." : "Update Post"}
                  </button>
                  <button
                    type="button"
                    className="btn btn-secondary"
                    onClick={() => navigate("/")}
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}