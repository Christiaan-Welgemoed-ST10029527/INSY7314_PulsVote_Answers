// frontend > src > components > Postlist.js
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

// Post component
const Post = (props) => (
  <tr>
    <td>{props.post.user}</td>
    <td>{props.post.content}</td>
    <td>{props.post.image}</td>
    <td>
      <Link className="btn btn-link" to={`/edit/${props.post._id}`}>Edit</Link> |
      <a
        className="btn btn-link"
        onClick={() => {
          props.deleteRecord(props.post._id);
        }}
      >
        Delete
      </a>
    </td>
  </tr>
);

export default function Postlist() {
  const [posts, setPosts] = useState([]);

  // This method fetches the records from the database.
  useEffect(() => {
    async function getPosts() {
      const response = await fetch(`http://localhost:3001/post/`);
      if (!response.ok) {
        const message = `An error occurred: ${response.statusText}`;
        window.alert(message);
        return;
      }
      const posts = await response.json();
      setPosts(posts);
    }
    getPosts();
    return;
  }, [posts.length]);

  // This method will delete a record
  async function deletePost(id) {
    const token = localStorage.getItem("jwt");
    await fetch(`http://localhost:3001/post/${id}`, {
      method: "DELETE",
      headers: {
        "Authorization": `Bearer ${token}`
      },
    });
    const newPosts = posts.filter((el) => el._id !== id);
    setPosts(newPosts);
  }

  // This method will map out the records on the table
  function postList() {
    return posts.map((post) => {
      return (
        <Post
          post={post}
          deleteRecord={() => deletePost(post._id)}
          key={post._id}
        />
      );
    });
  }

  return (
    <div>
      <div className="container">
        <h3 className="navbar-brand">APDS Notice Board</h3>
        <table className="table table-striped" style={{ marginTop: 20 }}>
          <thead>
            <tr>
              <th>User</th>
              <th>Caption</th>
              <th>Image</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>{postList()}</tbody>
        </table>
      </div>
    </div>
  );
}